-- Resource Metadata --

fx_version 'adamant'
game { 'gta5' }
lua54 'yes'

author 'buvarkaaa'
version '1.1'

-- Client / Server --

client_script 'Sources/Client/main.lua'
server_script 'Sources/Server/main.lua'

-- UI --

ui_page 'Sources/UI/ui.html'

files {
    'Sources/UI/ui.html',
    'Sources/UI/ui.css'
}