ESX = exports["es_extended"]:getSharedObject()

Citizen.CreateThread(function()
    TriggerServerEvent('getRealTime')
end)

Citizen.CreateThread(function()
    while true do
        local id = GetPlayerServerId(PlayerId())
        SendNUIMessage({
            type = "updatePlayerID",
            playerID = id
        })

        local playerData = ESX.GetPlayerData()
        local job = "N/A"
        if playerData.job then
            job = playerData.job.name
        end
        SendNUIMessage({
            type = "updatePlayerJob",
            job = job
        })

        Citizen.Wait(1000)  
    end
end)

RegisterNetEvent('updateClock')
AddEventHandler('updateClock', function(hour, minute)
    SendNUIMessage({
        type = "updateClock",
        hour = hour,
        minute = minute
    })
end)


function DrawTxt(x,y ,width,height,scale, text, r,g,b,a)
    SetTextFont(4)
    SetTextProportional(0)
    SetTextScale(scale, scale)
    SetTextColour(r, g, b, a)
    SetTextDropShadow(0, 0, 0, 0,255)
    SetTextEdge(2, 0, 0, 0, 255)
    SetTextOutline()
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(x - width/2, y - height/2 + 0.005)
end
