ESX = exports["es_extended"]:getSharedObject()

-- Az aktuális valós idejű idő lekérése és továbbítása a szervernek, amikor a kliens indul
Citizen.CreateThread(function()
    TriggerServerEvent('getRealTime')
end)

-- Játékos azonosítójának, frakcióinformációjának és időnek küldése a HUD-nak
Citizen.CreateThread(function()
    while true do
        -- Játékos azonosítójának küldése a HUD-nak
        local id = GetPlayerServerId(PlayerId())
        SendNUIMessage({
            type = "updatePlayerID",
            playerID = id
        })

        -- Frakcióinformációk lekérése és küldése a HUD-nak
        local playerData = ESX.GetPlayerData()
        local job = "N/A"
        if playerData.job then
            job = playerData.job.name
        end
        SendNUIMessage({
            type = "updatePlayerJob",
            job = job
        })

        Citizen.Wait(1000)  -- Például minden 1 másodpercben frissítjük a HUD-ot
    end
end)

-- Az időt frissítjük, amikor a szerver küldi az adatokat
RegisterNetEvent('updateClock')
AddEventHandler('updateClock', function(hour, minute)
    -- Az idő megjelenítése a HUD-on
    SendNUIMessage({
        type = "updateClock",
        hour = hour,
        minute = minute
    })
end)


function DrawTxt(x,y ,width,height,scale, text, r,g,b,a)
    SetTextFont(4)
    SetTextProportional(0)
    SetTextScale(scale, scale)
    SetTextColour(r, g, b, a)
    SetTextDropShadow(0, 0, 0, 0,255)
    SetTextEdge(2, 0, 0, 0, 255)
    SetTextOutline()
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(x - width/2, y - height/2 + 0.005)
end
