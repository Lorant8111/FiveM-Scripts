ESX = exports["es_extended"]:getSharedObject()

RegisterServerEvent('getPlayerInfo')
AddEventHandler('getPlayerInfo', function()
    local source = source
    local player = ESX.GetPlayerFromId(source)
    local job = player.job.name

    TriggerClientEvent('updatePlayerInfo', source, job)
end)

-- Esemény az aktuális valós idejű idő lekéréséhez és továbbításához a kliensnek
RegisterServerEvent('getRealTime')
AddEventHandler('getRealTime', function()
    local hour = tonumber(os.date("%H"))
    local minute = tonumber(os.date("%M"))

    -- Az időt minden játékosnak elküldjük
    TriggerClientEvent('updateClock', -1, hour, minute)
end)
