fx_version 'adamant'
game 'gta5'
lua54 'yes'

author 'buvarkaaa'
version '1.0'
description 'Ez a script eltünteti az NPC-ket'

client_script 'client.lua'