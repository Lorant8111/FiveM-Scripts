local kmh = 3.6 -- Kilóméter per óra / Kilometer per hour
local mph = 2.2369 -- Mérföld per óra / Miles per hour

function showText(text)
    SetTextFont(7) -- Speedometer betűtípus / Speedometer Font (1-7)
    SetTextProportional(0)
    SetTextScale(1.0, 2.0) -- Szöveg mérete / Label size
    SetTextOutline() -- Label Outline (Ne nyúlj hozzá / DONT TOUCH)                                           -- Kiírás beállításai / Label settings
    SetTextEntry("STRING") -- Speedometer felirat / Speedometer label
    AddTextComponentString(text)
    SetTextColour(255,255,0, 255) -- Speedometer színe / Speedometer color
    DrawText(0.889, 0.75)  -- Speedometer elhelyezkedés / Speedometer location
end


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1) -- Kis késleltetés a crash elkerülése érdekében / A little delay to avoid crashes
        local speed = (GetEntitySpeed(GetVehiclePedIsIn(GetPlayerPed(-1), false))*kmh) -- kmh vagy mph / kmh or mph
            if (IsPedInAnyVehicle(GetPlayerPed(-1), false)) then
                if speed < 1 then
                    showText("0")                                                                            -- Kiírás / Label (DONT TOUCH / NE ÉRJ HOZZÁ)
                else
                    showText(math.floor(speed))
                end
        end
    end
end)