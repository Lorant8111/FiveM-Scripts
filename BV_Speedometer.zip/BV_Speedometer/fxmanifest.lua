fx_version 'adamant'
game 'gta5'
lua54 'yes'

author 'buvarkaaa'

client_scripts {
  'client.lua'
} 