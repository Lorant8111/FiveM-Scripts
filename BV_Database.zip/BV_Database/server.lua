-- Csatlakozás --
AddEventHandler("playerConnecting", function(name, setKickReason, deferrals)
    deferrals.defer()
    deferrals.update("Játékos információk lekérése...")
    local soruce = source
    local playerName = GetPlayerName(source)
    local playerId = GetPlayerIdentifier(source)

    MySQL.Async.fetchAll("SELECT * FROM players WHERE player_id = @playerId", {
      ['@playerId'] = playerId
    }, function(result)
      if result[1] ~= nil then
        deferrals.done()
      else
        deferrals.update("Játékos információk regisztrálása...")

          MySQL.Async.execute("INSERT INTO players (player_id, player_name) VALUES (@playerId, @playerName)", {
            ['@playerId'] = playerId,
            ['@playerName'] = playerName
          }, function(rowsAffected)
                deferrals.done()
          end)
      end
    end)
end)