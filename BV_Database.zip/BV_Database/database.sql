CREATE DATABASE IF NOT EXISTS `es_extended`;
USE `es_extended`;

CREATE TABLE IF NOT EXISTS `players` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `player_id` varchar(50) NOT NULL,
    `player_name` varchar(50) NOT NULL,
    PRIMARY KEY (`id`)
);