fx_version 'adamant'
game 'gta5'
lua54 'yes'

author 'buvarkaaa'
version '1.0'
description 'Egy adatbázis script, ami hozzáadja a játékosok steamid-ját az adatbázishoz.'

server_scripts {
  'server.lua',
  '@mysql-async/lib/MySQL.lua'
}

dependency 'mysql-async'